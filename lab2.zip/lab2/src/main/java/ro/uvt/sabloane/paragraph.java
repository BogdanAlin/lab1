package ro.uvt.sabloane;

public class paragraph {
}
