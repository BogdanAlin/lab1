package ro.uvt.sabloane;

public class author {
    private final String nume;

    public author(String nume){
        this.nume=nume;
    }
}
