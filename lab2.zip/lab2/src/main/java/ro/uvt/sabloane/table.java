package ro.uvt.sabloane;

public class table {
}
