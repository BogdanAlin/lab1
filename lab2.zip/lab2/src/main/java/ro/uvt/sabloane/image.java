package ro.uvt.sabloane;

public class image {
}
